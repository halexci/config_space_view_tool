#!/bin/bash
#PBS -N Cun4-D
#PBS -l nodes=1:ppn=12
#PBS -l walltime=24:00:00
#PBS -q cmsp

source /etc/profile.d/modules.sh
module purge
module load espresso/5.0.3


#Directories info
CURRENT_DIR='/home/jmontoya/Cu_Clusters/n_4-Apr-2015D'
PSEUDO_DIR='/home/jmontoya/Cu_Clusters/Pseudo'

###################################################
NAME='Cun_4'
k="113"
klimit="125"

cd $CURRENT_DIR
echo "  Compiling Fortran utilities...\c"
gfortran common/randompos.f90  -o common/randompos.x 
echo " done"

######################## INPUT FILE ##############################
cat > cntrl.in1 << EOF
&control
           title = '$NAME' ,
     calculation = 'relax' ,
    restart_mode = 'from_scratch' ,
       verbosity = 'minimal' ,
         disk_io = 'none' ,
          prefix = 'Cun' ,
      pseudo_dir = '$PSEUDO_DIR' ,
          outdir = '/tmp' ,
     max_seconds = 1800 ,
   etot_conv_thr = 1.0d-6 ,
   forc_conv_thr = 1.0d-3 ,
/
EOF
cat > cntrl.in2 << EOF
&control
           title = '$NAME' ,
     calculation = 'relax' ,
    restart_mode = 'from_scratch' ,
       verbosity = 'minimal' ,
         disk_io = 'none' ,
          prefix = 'Cun' ,
      pseudo_dir = '$PSEUDO_DIR' ,
          outdir = '/tmp' ,
     max_seconds = 1800 ,
   etot_conv_thr = 1.0d-7 ,
   forc_conv_thr = 1.0d-3 ,
/
EOF
cat > sys.in1 << EOF
&system
           ibrav = 1 ,
       celldm(1) = 20 ,
             nat = 4 ,
            ntyp = 1 ,
     occupations = 'smearing' ,
        smearing = 'mp' ,
         degauss = 1d-5 ,
         ecutwfc = 25.0 ,
         ecutrho = 250.0 ,
 assume_isolated = 'mp'
/
EOF
cat > sys.in2 << EOF
&system
           ibrav = 1 ,
       celldm(1) = 20 ,
             nat = 4 ,
            ntyp = 1 ,
     occupations = 'smearing' ,
        smearing = 'mp' ,
         degauss = 1d-5 ,
         ecutwfc = 60.0 ,
         ecutrho = 600.0 ,
 assume_isolated = 'mp'
/
EOF
cat > elect.in1 << EOF
&electrons
        conv_thr = 1.0d-7 ,
     mixing_mode = 'local-TF' ,
     mixing_beta = 0.60 ,
 diagonalization = 'david' ,
/
EOF
cat > elect.in2 << EOF
&electrons
        conv_thr = 1.0d-8 ,
     mixing_mode = 'local-TF' ,
     mixing_beta = 0.65 ,
     startingwfc = 'atomic' ,
 diagonalization = 'david'
/
EOF
cat > ions.in1 << EOF
&ions
    ion_dynamics = 'bfgs' ,
         upscale = 30.D0 ,
trust_radius_ini = 3.0D-1 ,
trust_radius_max = 6.0D-1 ,
trust_radius_min = 1.0D-8
/
EOF
cat > ions.in2 << EOF
&ions
    ion_dynamics = 'bfgs' ,
         upscale = 30.D0 ,
trust_radius_ini = 5.0D-2 ,
trust_radius_max = 5.0D-1 ,
trust_radius_min = 1.0D-10
/
EOF
cat > cards.in1 << EOF
ATOMIC_SPECIES
    Cu   63.546  Cu.pbe-n-van_ak.UPF
K_POINTS {automatic}
 2 2 2  0 0 0
EOF
cat > cards.in2 << EOF
ATOMIC_SPECIES
    Cu   63.546  Cu.pbe-n-van_ak.UPF
K_POINTS {automatic}
 4 4 4  0 0 0
EOF
###################################################################
while [ "$k" -le "$klimit" ] # OR: for k in $Systems
do
########### CREATES NEW WORKING DIRECTORY ########
if [ ! -e System$k ];   then
mkdir -p System$k/tmp
fi
cd System$k
##################################################
if [ ! -e atompos.in ];   then
   echo "  In System$k: atompos does not exist... creating"
   ../common/randompos.x > atompos.in
   cat atompos.in > pos_hist.dat
   echo "  done"
fi
cp  ../cntrl.in1 01$NAME.in
cat ../sys.in1 >> 01$NAME.in
cat ../elect.in1 >> 01$NAME.in
cat ../ions.in1 >> 01$NAME.in
cat ../cards.in1 >> 01$NAME.in
cat >> 01$NAME.in < atompos.in

echo "  1st RELAXATION...\c"
mpirun pw.x -npool 2 -inp 01$NAME.in > 01$NAME.out
echo "  done"
   
if [ -e CRASH ];   then
   echo "  CRASH on first try!!!"
   touch ../CRASH$k.A
   rm ./CRASH
fi
if [ -e ../EXIT ];   then
   k=$((klimit+1))
   echo "Aborted by User!!!"
   rm ../EXIT
else
   grep -A 4 "ATOMIC_POSITIONS" 01$NAME.out | tail -n 5 > atompos.in
   cat atompos.in >> pos_hist.dat
fi
cp  ../cntrl.in2 02$NAME.in
cat ../sys.in2 >> 02$NAME.in
cat ../elect.in2 >> 02$NAME.in
cat ../ions.in2 >> 02$NAME.in
cat ../cards.in2 >> 02$NAME.in
cat >> 02$NAME.in < atompos.in

echo "  2nd RELAXATION...\c"
mpirun pw.x -npool 2 -inp 02$NAME.in > 02$NAME.out
echo "  done"

if [ -e CRASH ];   then
   echo "  CRASH on 2nd try!!!"
   touch ../CRASH$k.B
   rm ./CRASH
fi
if [ -e ../EXIT ];   then
   k="$klimit"
   echo "Aborted by User!!!"
   rm ../EXIT
fi
cd $CURRENT_DIR
k=$((k+1))
done

k=$((k-1))
echo "Tot. Systems = $k"
rm *.in?
rm common/*.x
